import type { Metadata } from "next";
import Image from "next/image";
import SectionHeading from "@/components/SectionHeading";

export const metadata: Metadata = {
  title: "Marka Hikayesi",
  description:
    "Abrek Gear'ın kuruluş amacı, üretim felsefesi ve profesyoneller için taktik giyim tasarlama sürecini keşfedin.",
};

const values = [
  {
    title: "Fonksiyon Önce",
    text: "Bir parça yalnızca iyi görünmekle kalmaz; belirli bir ihtiyacı gerçek koşullarda karşılamalıdır.",
  },
  {
    title: "Uzun Ömür",
    text: "Sık sık değişen koleksiyonlar yerine, yıllarca kullanılabilecek parçalar tasarlıyoruz.",
  },
  {
    title: "Şeffaflık",
    text: "Kumaş, üretim yeri ve teknik detaylar konusunda hiçbir bilgiyi müşterilerimizden saklamıyoruz.",
  },
];

const timeline = [
  {
    year: "2019",
    text: "Abrek Gear, saha ekipmanlarındaki kalite eksikliğine bir yanıt olarak küçük bir atölyede kuruldu.",
  },
  {
    year: "2021",
    text: "İlk teknik tişört ve polar serisi, dağcılık ve outdoor topluluklarından yoğun geri bildirim aldı.",
  },
  {
    year: "2023",
    text: "Üretim kapasitesi arttı; hoodie ve taktik aksesuar kategorileri koleksiyona eklendi.",
  },
  {
    year: "2026",
    text: "Abrek Gear, profesyonel kullanıcılar için tam kapsamlı bir taktik giyim markasına dönüştü.",
  },
];

export default function AboutPage() {
  return (
    <div>
      <section className="relative h-[60vh] min-h-[420px] flex items-end overflow-hidden">
        <Image
          src="https://picsum.photos/seed/abrek-about-hero/1920/1000"
          alt="Abrek Gear atölyesinde üretim süreci"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/60 to-obsidian/10" />
        <div className="container-max relative px-6 md:px-10 lg:px-16 pb-16">
          <span className="eyebrow">Marka Hikayesi</span>
          <h1 className="font-display uppercase text-4xl md:text-6xl tracking-wide mt-4 max-w-2xl">
            Kolaya Kaçmadan Üretmek
          </h1>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-max grid md:grid-cols-2 gap-12 items-start">
          <SectionHeading
            eyebrow="Başlangıç"
            title="Bir İhtiyaçtan Doğan Marka"
          />
          <div className="flex flex-col gap-5 text-sand/75 leading-relaxed">
            <p>
              Abrek Gear, piyasadaki taktik giyim ürünlerinin çoğunun ya çok
              ucuz ve dayanıksız ya da gereğinden fazla süslü ve işlevsiz
              olduğu gözleminden yola çıkarak kuruldu. Amacımız, sahada
              gerçekten işe yarayan ama aynı zamanda özenle tasarlanmış bir
              koleksiyon oluşturmaktı.
            </p>
            <p>
              Bugün Abrek Gear, dağcılık eğitmenlerinden outdoor
              fotoğrafçılara, saha çalışanlarından günlük kullanıcılara kadar
              geniş bir kitleye hitap ediyor. Ortak nokta değişmedi: dayanıklı,
              sade ve amacına uygun giyim arayışı.
            </p>
          </div>
        </div>
      </section>

      <section className="section-pad bg-obsidian-light">
        <div className="container-max">
          <SectionHeading
            eyebrow="Değerlerimiz"
            title="Bizi Yönlendiren İlkeler"
            align="center"
          />
          <div className="grid md:grid-cols-3 gap-6">
            {values.map((v) => (
              <div
                key={v.title}
                className="border border-line p-8 hover:border-gold/40 transition-colors duration-300"
              >
                <h3 className="font-display uppercase text-lg tracking-wide mb-3">
                  {v.title}
                </h3>
                <p className="text-sand/70 text-sm leading-relaxed">
                  {v.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-max">
          <SectionHeading eyebrow="Zaman Çizelgesi" title="Bugüne Kadar" />
          <div className="flex flex-col">
            {timeline.map((item, i) => (
              <div
                key={item.year}
                className="grid grid-cols-[80px_1fr] md:grid-cols-[140px_1fr] gap-6 py-6 border-t border-line last:border-b"
              >
                <span className="font-mono text-gold-light text-lg">
                  {item.year}
                </span>
                <p className="text-sand/75 leading-relaxed">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
