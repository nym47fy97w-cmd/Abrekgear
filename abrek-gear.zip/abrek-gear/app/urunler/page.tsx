import { Suspense } from "react";
import type { Metadata } from "next";
import ProductsClient from "./ProductsClient";

export const metadata: Metadata = {
  title: "Koleksiyon | Tüm Ürünler",
  description:
    "Abrek Gear'ın tişört, polar, hoodie, şapka, patch ve taktik aksesuar koleksiyonunu keşfedin. Sahada test edilmiş, premium taktik giyim.",
};

export default function ProductsPage() {
  return (
    <Suspense fallback={null}>
      <ProductsClient />
    </Suspense>
  );
}
