import type { Metadata } from "next";
import ContactForm from "./ContactForm";
import SectionHeading from "@/components/SectionHeading";

export const metadata: Metadata = {
  title: "İletişim",
  description:
    "Abrek Gear ekibine ulaşın. Sorularınız, kurumsal işbirlikleri ve sipariş desteği için bize yazın.",
};

const info = [
  { label: "E-posta", value: "destek@abrekgear.com" },
  { label: "Telefon", value: "+90 (212) 555 01 42" },
  { label: "Adres", value: "Maslak Mah. Büyükdere Cd. No:1, İstanbul" },
  { label: "Çalışma Saatleri", value: "Hafta içi 09:00 – 18:00" },
];

export default function ContactPage() {
  return (
    <div className="section-pad pt-14">
      <div className="container-max">
        <SectionHeading
          eyebrow="İletişim"
          title="Bize Ulaşın"
          description="Sorularınızı yanıtlamaktan memnuniyet duyarız. Ekibimiz genellikle 24 saat içinde geri dönüş sağlar."
        />

        <div className="grid lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <ContactForm />
          </div>

          <div className="flex flex-col gap-6">
            {info.map((item) => (
              <div key={item.label} className="border-t border-line pt-4">
                <p className="eyebrow mb-1">{item.label}</p>
                <p className="text-sand/80 text-sm">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
