import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { blogPosts } from "@/lib/data";
import SectionHeading from "@/components/SectionHeading";

export const metadata: Metadata = {
  title: "Bülten",
  description:
    "Malzeme bilgisi, katmanlı giyim rehberleri ve Abrek Gear üretim sürecine dair yazılar.",
};

export default function BlogPage() {
  const [first, ...rest] = blogPosts;

  return (
    <div className="section-pad pt-14">
      <div className="container-max">
        <SectionHeading
          eyebrow="Bülten"
          title="Saha Notları"
          description="Malzeme, üretim ve kullanım üzerine yazılar."
        />

        {first && (
          <Link
            href={`/blog/${first.slug}`}
            className="group grid md:grid-cols-2 gap-8 mb-16 border border-line hover:border-gold/40 transition-colors duration-300"
          >
            <div className="relative aspect-[16/10] md:aspect-auto overflow-hidden bg-khaki-dark">
              <Image
                src={first.image}
                alt={first.title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            </div>
            <div className="p-8 flex flex-col justify-center">
              <span className="eyebrow mb-3">{first.category}</span>
              <h2 className="font-display uppercase text-2xl md:text-3xl tracking-wide mb-4 group-hover:text-gold-light transition-colors">
                {first.title}
              </h2>
              <p className="text-sand/70 text-sm leading-relaxed mb-4">
                {first.excerpt}
              </p>
              <span className="text-xs font-mono text-sand/50">
                {first.date} · {first.readTime} okuma
              </span>
            </div>
          </Link>
        )}

        <div className="grid md:grid-cols-3 gap-6">
          {rest.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group border border-line hover:border-gold/40 transition-colors duration-300"
            >
              <div className="relative aspect-[16/10] overflow-hidden bg-khaki-dark">
                <Image
                  src={post.image}
                  alt={post.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
              </div>
              <div className="p-6">
                <span className="eyebrow mb-3 block">{post.category}</span>
                <h3 className="font-display uppercase text-lg tracking-wide mb-3 group-hover:text-gold-light transition-colors">
                  {post.title}
                </h3>
                <p className="text-sand/65 text-sm leading-relaxed mb-4 line-clamp-2">
                  {post.excerpt}
                </p>
                <span className="text-xs font-mono text-sand/50">
                  {post.date} · {post.readTime} okuma
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
