import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { blogPosts } from "@/lib/data";

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Metadata {
  const post = blogPosts.find((p) => p.slug === params.slug);
  if (!post) return { title: "Yazı Bulunamadı" };
  return {
    title: post.title,
    description: post.excerpt,
  };
}

export default function BlogDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = blogPosts.find((p) => p.slug === params.slug);
  if (!post) return notFound();

  const others = blogPosts.filter((p) => p.slug !== post.slug).slice(0, 2);

  return (
    <article>
      <section className="relative h-[50vh] min-h-[380px] flex items-end overflow-hidden">
        <Image
          src={post.image}
          alt={post.title}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-obsidian/60 to-obsidian/10" />
        <div className="container-max relative px-6 md:px-10 lg:px-16 pb-14">
          <span className="eyebrow">{post.category}</span>
          <h1 className="font-display uppercase text-3xl md:text-5xl tracking-wide mt-4 max-w-3xl">
            {post.title}
          </h1>
          <p className="text-xs font-mono text-sand/60 mt-4">
            {post.date} · {post.readTime} okuma
          </p>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-max max-w-2xl mx-auto flex flex-col gap-6">
          {post.content.map((paragraph, i) => (
            <p key={i} className="text-sand/80 leading-relaxed text-[15px]">
              {paragraph}
            </p>
          ))}

          <div className="hairline mt-8 pt-8">
            <Link
              href="/blog"
              className="font-mono text-xs uppercase tracking-widest2 text-gold-light hover:text-gold"
            >
              ← Tüm Yazılara Dön
            </Link>
          </div>
        </div>
      </section>

      {others.length > 0 && (
        <section className="section-pad bg-obsidian-light">
          <div className="container-max">
            <h2 className="eyebrow mb-8">Diğer Yazılar</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {others.map((p) => (
                <Link
                  key={p.slug}
                  href={`/blog/${p.slug}`}
                  className="group flex gap-5 border border-line p-5 hover:border-gold/40 transition-colors duration-300"
                >
                  <div className="relative w-28 h-28 flex-shrink-0 overflow-hidden bg-khaki-dark">
                    <Image
                      src={p.image}
                      alt={p.title}
                      fill
                      className="object-cover"
                      sizes="112px"
                    />
                  </div>
                  <div>
                    <span className="eyebrow mb-2 block">{p.category}</span>
                    <h3 className="font-display uppercase text-base tracking-wide group-hover:text-gold-light transition-colors">
                      {p.title}
                    </h3>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </article>
  );
}
