import type { Metadata } from "next";
import SectionHeading from "@/components/SectionHeading";
import FaqAccordion from "./FaqAccordion";

export const metadata: Metadata = {
  title: "Sıkça Sorulan Sorular",
  description:
    "Kargo, iade, beden tablosu ve ödeme seçenekleri hakkında sıkça sorulan soruların yanıtlarını bulun.",
};

export default function FaqPage() {
  return (
    <div className="section-pad pt-14">
      <div className="container-max max-w-3xl">
        <SectionHeading
          eyebrow="Yardım Merkezi"
          title="Sıkça Sorulan Sorular"
          description="Aradığınız yanıtı bulamazsanız, iletişim sayfamızdan bize ulaşabilirsiniz."
        />
        <FaqAccordion />
      </div>
    </div>
  );
}
