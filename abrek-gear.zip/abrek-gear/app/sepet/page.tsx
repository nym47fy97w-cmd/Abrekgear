"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/lib/cart-context";
import { formatPrice } from "@/lib/utils";

export default function CartPage() {
  const { items, removeItem, updateQuantity, totalPrice, clearCart } =
    useCart();
  const [checkoutDone, setCheckoutDone] = useState(false);

  const shipping = totalPrice > 1500 || totalPrice === 0 ? 0 : 79;
  const grandTotal = totalPrice + shipping;

  if (checkoutDone) {
    return (
      <div className="section-pad min-h-[60vh] flex items-center justify-center">
        <div className="text-center max-w-md">
          <span className="font-mono text-gold-light text-sm uppercase tracking-widest2">
            Sipariş Alındı
          </span>
          <h1 className="font-display uppercase text-3xl mt-4 mb-4">
            Teşekkürler.
          </h1>
          <p className="text-sand/70 mb-8">
            Siparişiniz onaylandı. Kargo takip bilgileriniz e-posta adresinize
            gönderilecektir.
          </p>
          <Link href="/urunler" className="btn-primary">
            Alışverişe Devam Et
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="section-pad pt-14">
      <div className="container-max">
        <div className="flex items-center gap-3 mb-4">
          <span className="w-8 h-[1.5px] bg-gold" />
          <span className="eyebrow">Sepetiniz</span>
        </div>
        <h1 className="font-display uppercase text-4xl md:text-5xl tracking-wide mb-12">
          Sepet
        </h1>

        {items.length === 0 ? (
          <div className="text-center py-24 border border-line">
            <p className="text-sand/60 mb-6">Sepetiniz şu anda boş.</p>
            <Link href="/urunler" className="btn-primary">
              Koleksiyonu İncele
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 flex flex-col gap-6">
              {items.map((item, i) => (
                <div
                  key={i}
                  className="flex gap-5 border-b border-line pb-6"
                >
                  <div className="relative w-24 h-28 md:w-28 md:h-32 flex-shrink-0 bg-khaki-dark overflow-hidden">
                    <Image
                      src={item.product.images[0]}
                      alt={item.product.name}
                      fill
                      className="object-cover"
                      sizes="120px"
                    />
                  </div>

                  <div className="flex-1 flex flex-col justify-between">
                    <div className="flex justify-between gap-4">
                      <div>
                        <p className="font-display uppercase tracking-wide">
                          {item.product.name}
                        </p>
                        <p className="text-xs text-sand/50 font-mono mt-1">
                          {item.color} / {item.size}
                        </p>
                        <p className="text-xs text-sand/40 font-mono mt-0.5">
                          {item.product.code}
                        </p>
                      </div>
                      <span className="font-mono text-gold-light whitespace-nowrap">
                        {formatPrice(item.product.price * item.quantity)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center border border-line">
                        <button
                          onClick={() =>
                            updateQuantity(i, item.quantity - 1)
                          }
                          className="w-9 h-9 text-sand/70 hover:text-gold-light"
                        >
                          −
                        </button>
                        <span className="w-8 text-center font-mono text-sm">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(i, item.quantity + 1)
                          }
                          className="w-9 h-9 text-sand/70 hover:text-gold-light"
                        >
                          +
                        </button>
                      </div>
                      <button
                        onClick={() => removeItem(i)}
                        className="text-xs text-sand/50 hover:text-red-400 underline"
                      >
                        Kaldır
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              <button
                onClick={clearCart}
                className="self-start text-xs text-sand/50 hover:text-red-400 underline font-mono uppercase tracking-wide"
              >
                Sepeti Boşalt
              </button>
            </div>

            {/* Özet */}
            <div className="border border-line p-6 h-fit sticky top-24">
              <h3 className="font-display uppercase tracking-wide text-lg mb-6">
                Sipariş Özeti
              </h3>
              <div className="flex flex-col gap-3 text-sm">
                <div className="flex justify-between text-sand/70">
                  <span>Ara Toplam</span>
                  <span className="font-mono">{formatPrice(totalPrice)}</span>
                </div>
                <div className="flex justify-between text-sand/70">
                  <span>Kargo</span>
                  <span className="font-mono">
                    {shipping === 0 ? "Ücretsiz" : formatPrice(shipping)}
                  </span>
                </div>
                {shipping > 0 && (
                  <p className="text-xs text-gold-light font-mono">
                    1.500₺ üzeri siparişlerde kargo ücretsizdir.
                  </p>
                )}
                <div className="hairline pt-3 flex justify-between font-display uppercase tracking-wide">
                  <span>Toplam</span>
                  <span className="font-mono text-gold-light text-lg">
                    {formatPrice(grandTotal)}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setCheckoutDone(true)}
                className="btn-primary w-full mt-8"
              >
                Ödemeye Geç
              </button>
              <Link
                href="/urunler"
                className="block text-center text-xs text-sand/50 hover:text-gold-light mt-4 font-mono uppercase tracking-wide"
              >
                ← Alışverişe Devam Et
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
